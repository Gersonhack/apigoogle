### Corrector de Erros Ortográficos
esse projecto, é um chatbot, que realiza
a função de corrigir erros ortográficos em todos os textos que lhe sera fornecido.
